#include <map>
#include <string>
#include <utility>
#include "Request.hpp"
#include "RequestParser.hpp"

class Client{
	private:

		//class로 만들고

	public:
		std::string		buff;
		Request			_request;
		
		
};

int main()
{

	Client A;
	RequestParser B;

	B.parsing(A._request, A.buff);	
	
}
