#include <map>
#include <string>

class Response{
	private:
		std::string _body;
};

method 처리
{
	메소드 권한 확인 : limit_accept에 allow를 확인
		서버 클래스에서 limit_accept 확인해서 없으면 에러코드(미정)
	
	key value
	setCookie >> map 
	쿠키 존재 여부 확인
		쿠키 있음
			통과
		쿠키 없음
			쿠키 관련 정보 생성
	
	인증 필요 여부 확인(세션)
		인증 필요 없음(세션 아이디 있음)
			통과
		인증 필요(세션아이디 없음)
			쿼리스트링 확인
				있음
					id/pw확인
						맞음
							통과
						틀리면
							401에러
				없으면
					401에러
	
	chmod권한 : 리소스 확인(파일, 함수)
		write.cgi  update.cgi, delete.cgi
		create, update, delete


		GET이면 cgi아닌 경우 파일로 왔다고 생각
		POST면 함수 내역에 있는지 보고, 없으면 파일로 인식.
			함수 내역에 있으면
				통과
			

		있음
			통과
		권한 없음
			에러코드 처리(미정, 확인 필요)
	
	메소드 확인
		GET
			FILE처리 할지 CGI처리 할지
				FILE
					파일 열기
						성공
							파일 읽기
							성공 >> 응답메세지 바디에 붙이기
							실패
						실패
				CGI
					환경변수 셋팅
					파이프
					포크
						자식 이벤트 추가 등록(epoll로)
						자식 이벤트 순번 됨
							exceve실행
					부모
					자식 이벤트 종료 체크
					pipe 읽기 이벤트 등록(epoll로)
					이벤트 순서가 되면 읽기
						성공 >> 응답메세지 바디에 붙이기
						실패

			응답메세지
				std::map<std::string, std::string> _responsTemp;
				statusLine = version code msg

				date, content-type, content-length
				body 붙이기

				response msg 만드는 클래스 만들어서. 
				


		POST

		DELETE

	GET naver.com/write HTTP/1.1

	write()
	/write
 
	


	
	
}
